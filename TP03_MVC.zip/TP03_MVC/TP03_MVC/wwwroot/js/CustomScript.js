﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TP03_MVC.wwwroot.js
{
    public class CustomScript
    {
        function confirmDelete(uniqueId, isDeleteClicked) {
        var deleteSpan = 'deleteSpan_' + uniqueId;
        var confirmDeleteSpan = 'confirmDeleteSpan_' + uniqueId;
        if (isDeleteClicked) {
            $('#' + deleteSpan).hide();
            $('#' + confirmDeleteSpan).show();
        } else {
            $('#' + deleteSpan).show();
            $('#' + confirmDeleteSpan).hide();
        }
    }
    }
}
